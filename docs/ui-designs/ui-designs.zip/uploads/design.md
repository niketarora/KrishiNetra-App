# Design Specification — Farmer Decision Support App

## How to use this document

This document is written to be handed to a UI-generation tool (e.g.
Google Stitch) or a designer/developer with zero prior context. Every
screen is described top-to-bottom with exact content, component types,
states, and navigation — nothing should require guessing. Where a value
is not yet finalized (e.g. exact copy strings that depend on ML output),
a representative example is given and marked "example data."

This is an independent app. It is not a copy of KrishiNetra. One data
point (theme-color `#0f3d27`, dark forest green) was noted from the
public KrishiNetra site as a loose category signal only — the palette
and every component below are original to this project.

Platform: Android, Flutter. Mobile-first, single-column, portrait only
for V1. Target: mid-range Android devices, outdoor daylight use.

---

## 1. Design Tokens

### 1.1 Color

| Token | Hex | Usage |
|---|---|---|
| `color/primary` | `#2E7D4F` | Primary buttons, active nav icon/label, confirm actions, FAB |
| `color/primary-dark` | `#1B5236` | Pressed state of primary, text on `bg/success` |
| `color/bg` | `#F7F8F4` | Screen background |
| `color/surface` | `#FFFFFF` | Cards, sheets |
| `color/border` | `#E2E4DC` | 0.5–1dp hairlines around cards |
| `color/success` | `#3E8F5C` | Success icon/text |
| `bg/success` | `#E8F5EC` | Success badge/banner background |
| `color/warning` | `#B8720A` | Warning icon/text |
| `bg/warning` | `#FBEEDC` | Warning badge/banner background |
| `color/danger` | `#B23A2E` | Danger icon/text, error banners |
| `bg/danger` | `#FBE7E4` | Danger badge/banner background |
| `color/accent` | `#1E6FA8` | Market/informational elements, links |
| `bg/accent` | `#E6F1FA` | Market recommendation card background |
| `text/primary` | `#1C1F1A` | Body copy, headings |
| `text/secondary` | `#5B6058` | Labels, captions, sub-values |
| `text/muted` | `#8B8F86` | Timestamps, placeholder, disabled |
| `text/on-primary` | `#FFFFFF` | Text/icons on solid primary green |

Rule: warning/danger colors are reserved exclusively for states requiring
farmer attention or representing failure. They never appear decoratively.

### 1.2 Typography

Font family: system default (Roboto on Android). No custom font
download — performance on low-end devices matters more than brand
typography here. Two weights only.

| Style | Size | Weight | Usage |
|---|---|---|---|
| `type/title` | 18sp | Medium (500) | Screen titles |
| `type/card-title` | 16sp | Medium (500) | Card headlines, key values |
| `type/body` | 14sp | Regular (400) | Body copy |
| `type/caption` | 13sp | Regular (400) | Labels, secondary values |
| `type/micro` | 12sp | Regular (400) | Timestamps, hints, badge text |

Sentence case everywhere. No all-caps labels — poor readability at
distance/glare and inconsistent across 22 target languages.

### 1.3 Spacing scale

`4 / 8 / 12 / 16 / 24 / 32` dp. Screen horizontal padding: `16dp`.
Card internal padding: `14–16dp`. Gap between stacked cards: `12dp`.

### 1.4 Shape

- Card corner radius: `12dp`
- Button/badge/input corner radius: `8dp`
- Card border: `0.5dp`, `color/border`
- No shadows/elevation — flat design, border-only separation (keeps
  performance high on low-end devices and avoids muddy rendering in
  bright outdoor light)

### 1.5 Iconography

Single outline icon set throughout (e.g. Material Symbols Outlined or
Tabler Icons Outline — pick one and use exclusively, never mix sets).
Icons inherit `text/secondary` by default, or the semantic color of
their container (success/warning/danger/accent). Standard sizes: 18dp
inline, 20–24dp leading, 28–32dp decorative/empty-state.

---

## 2. Global Layout Rules

- **Status bar:** system default, content does not draw under it.
- **Screen padding:** 16dp left/right on all screens except the map
  (edge-to-edge) and modal overlays (own padding rules below).
- **Bottom navigation bar:** fixed, 56–64dp height, 4 items — Home,
  Field, Market, History. Profile is NOT in bottom nav; it lives behind
  the avatar icon in the top-right of Home/other screens' header.
  Active item: `color/primary` icon + label. Inactive: `text/muted`.
- **Floating voice button (FAB):** 56dp diameter circle, solid
  `color/primary`, mic icon in `text/on-primary`, positioned bottom
  right, anchored so its center sits on the top edge of the bottom nav
  bar (half above, half overlapping). Present on Home, Field, and
  Market. Not present on Login/OTP/Splash. Not present on Profile
  (secondary/settings context). See open question in Section 9.
- **Headers:** screens other than Home use a simple header row — back
  arrow (if not a root tab) + `type/title` screen name, 56dp height, no
  border, background matches screen background (no distinct app bar
  surface).

---

## 3. Component Library

### 3.1 Primary button
Full width, 48dp height, `color/primary` fill, `text/on-primary` label
14sp/500, `radius/8`. One per screen maximum. Pressed state: darken to
`primary-dark`.

### 3.2 Secondary button
Full width or auto width, 44dp height, transparent fill, `0.5dp`
`color/border-strong`-equivalent outline, `text/primary` label. Used for
"undo," "restart," "see reasoning," "edit field."

### 3.3 Status card
`color/surface` background, `radius/12`, `0.5dp` `color/border`,
padding 12–14dp. Contents: leading icon (20dp, `text/secondary`),
`type/caption` label below icon, `type/card-title` value below label.
Used in a 2-column grid for moisture/growth-stage on Home.

### 3.4 Alert / advisory banner
Tinted background (`bg/warning` or `bg/danger`), `radius/12`, padding
12–14dp, no border. Leading icon (20dp, semantic color) + `type/body`
title (semantic color, 500 weight) + `type/caption` detail line
(`text/secondary`). Only rendered when the condition is active — collapses
entirely otherwise (does not show a "no alert" empty state on Home).

### 3.5 Recommendation card (market)
`bg/accent` background, `radius/12`, padding 14–16dp. Header row: title
(`type/card-title`, `color/accent`, weight 500) + confidence badge
(right-aligned, pill). Body: one-sentence recommendation
(`type/caption`, `text/secondary`), one-sentence reasoning
(`type/micro`, `text/muted`).

### 3.6 Badge / pill
Auto-width, `radius/8`, padding `4dp 10dp`, `type/micro` text, tinted
background matching its semantic role (success/warning/danger/accent/
neutral-gray for confidence labels).

### 3.7 Field summary card
`color/surface`, `radius/12`, padding 14dp. Left: field name
(`type/card-title`), area + crop (`type/caption`, `text/muted`). Right:
health badge, top-aligned.

### 3.8 Bottom navigation item
Vertical stack: icon (20dp) over label (`type/micro`), 4 equal-width
columns, active item colored `color/primary`, inactive `text/muted`.

### 3.9 Map polygon (field drawing)
Satellite/map background fills the container. Confirmed/in-progress
boundary drawn as a closed or open polyline, `color/primary` stroke
2–3dp, `bg/success`-equivalent semi-transparent fill (30% opacity green)
inside a closed polygon. Vertex points: 8–10dp filled circles,
`color/primary`, tappable/draggable for correction. A small pill
overlay top-left reads "Satellite view."

### 3.10 Sparkline (market trend)
Single-line SVG/Canvas trend line, no axes, no gridlines, no data
labels — `color/success` or `color/danger` stroke depending on trend
direction, 2dp width, contained in a 40dp-tall strip under the price
row.

### 3.11 Text input (phone, OTP)
44–48dp height, `color/surface` background, `0.5dp` `color/border`,
`radius/8`, 16sp input text, placeholder in `text/muted`.

### 3.12 Crop/tab selector
Horizontal scrollable row of pills, active pill filled `color/primary`
with `text/on-primary` text, inactive pills outlined with `text/secondary`
text.

---

## 4. Screens

### 4.1 Splash

Purpose: brand moment + session check (logged in → Home, not logged in →
Language select).

Layout: full-bleed `color/bg`, centered app logo/wordmark, no text below
it, no loading spinner unless session check exceeds ~1s (then a small
indeterminate spinner appears centered below the mark). Duration: as
short as possible, this is not a marketing screen.

### 4.2 Language Selection

Purpose: choose the app's display and voice-assistant language before
anything else, since this affects every subsequent screen.

Layout: `type/title` "Choose your language" centered top, 24dp below a
scrollable vertical list of language options as full-width rows (44dp
tall, `color/border` divider between rows, no cards) — language name
shown in its own script (e.g. "हिन्दी", "தமிழ்", "English"). Selected row
gets a trailing check icon in `color/primary`. Bottom: primary button
"Continue," disabled state (see input validation rule) until a
selection is made. No back button — this is the first screen after
splash for new users.

### 4.3 Login (Phone Number)

Layout: `type/title` "Enter your phone number" top, `type/caption`
helper line below ("We'll send a one-time code to verify"), phone input
field (component 3.11) with a fixed "+91" prefix chip on its left edge,
primary button "Send code" pinned bottom (44–48dp above bottom edge,
16dp side margins). Validation: button is tappable at all times; on tap
with an invalid/short number, show inline error text 13sp
`color/danger` below the field ("Enter a valid 10-digit number") and do
not proceed.

### 4.4 OTP Verification

Layout: `type/title` "Enter the code" top, `type/caption` "Sent to
+91 XXXXX XXXXX" below, 6 individual boxed digit inputs centered
(44dp square each, `radius/8`, `color/border`, auto-advance focus),
"Resend code" text link (`color/accent`) below, disabled/greyed with a
30s countdown label until resend is allowed, primary button "Verify"
pinned bottom. Error state: boxes outline turns `color/danger` and
`type/caption` "Incorrect code, try again" appears above the resend
link.

### 4.5 Home Dashboard

Purpose: answer "what should I know about my field today?" in one
screen, no scrolling required for the critical info (alert + health).

Layout, top to bottom, 16dp side padding, 12dp vertical gaps:
1. Header row: "Good morning" (`type/caption`, `text/secondary`) over
   farmer's first name (`type/card-title`), right-aligned circular
   avatar (32dp, initials or icon) that opens Profile.
2. Field summary card (component 3.7). Example data: "North plot",
   "2.4 acres · Wheat", health badge "Good health" (`bg/success`).
3. 2-column grid of status cards (component 3.3): Soil moisture
   ("Low"), Growth stage ("Flowering"). Icons: droplet, plant.
4. Conditional alert banner (component 3.4) — only when irrigation or
   crop-health action is needed. Example: title "Irrigation needed"
   (warning), detail "Within 24 hours · ~450 litres/acre".
5. Secondary button, full width: "View full analysis" → Field Analysis
   Detail screen.
6. Market summary card: `color/surface`, `radius/12`, padding 14dp.
   Label "Market" (`type/caption`), row with price
   (`type/card-title`, e.g. "Rs 2,450/quintal") + trend caption below
   it (`type/micro`, `text/muted`, e.g. "7-day trend +6.2%"), and a
   right-aligned recommendation badge (e.g. "Partial sell",
   `bg/accent`).
7. Bottom navigation + FAB per Section 2.

States:
- **Loading (first load / refresh):** field summary and status cards
  render as skeleton blocks (flat `color/border`-tinted rectangles, no
  shimmer animation — keep it cheap on low-end devices) with a
  `type/caption` "Analyzing your field…" centered below the field card.
- **Low confidence:** confidence badge appears on the field summary
  card reading "Limited confidence" (neutral gray pill), and the alert
  banner (if present) uses softened language, e.g. "May need irrigation
  soon" instead of "Required."
- **No ML coverage:** field summary card shows a neutral state — health
  badge replaced with "Not yet analyzed," status cards show "—" instead
  of a value, and a `type/caption` note "This field is currently outside
  supported analysis coverage" appears where the alert banner would go.
- **Outdated data:** a `type/micro` `text/muted` line "Last analyzed 3
  days ago" appears under the field summary card.
- **API failure:** a dismissible danger banner appears at the very top
  of the scroll area (above the header): "We couldn't update your field
  right now. Your last available result is still shown." Rest of the
  screen renders with the last cached data.
- **Offline:** same pattern as API failure but neutral/gray banner:
  "You're offline. Showing your latest saved information."

### 4.6 Field Setup — Location / Field Name (pre-drawing)

Purpose: only reached the first time a farmer has no field yet, or when
re-creating a field.

Layout: `type/title` "Let's find your field" top, `type/body` one-line
explainer, a search input (component 3.11) with a location-pin leading
icon for entering village/area name to center the map, primary button
"Continue to map." (If GPS permission is available, this step can
auto-skip using device location — the search field still exists as a
fallback.)

### 4.7 Field Setup — Draw Boundary

Purpose: the app's only real manual task.

Layout: header row "Draw your field" with back arrow, edge-to-edge map
container below (fills remaining vertical space above the bottom
control panel) using satellite imagery with the "Satellite view" pill
label top-left (component 3.9 for the drawing itself), a two-button row
directly below the map — secondary buttons "Undo point" and "Restart,"
each 50% width with 8dp gap between them — then a calculated-area card
(`color/surface`, `radius/12`, padding 14dp) showing three values in a
row: acres, hectares, sq metres, each as a stacked `type/card-title`
value over `type/micro` unit label — and finally a primary button
"Confirm field boundary" pinned to the bottom. The area card and confirm
button are only enabled once the polygon has at least 3 vertices and is
closed.

### 4.8 Field Setup — Confirmation

Purpose: name the field and trigger the initial analysis request.

Layout: `type/title` "Confirm your field" top, a static preview of the
drawn polygon (non-editable, smaller map thumbnail, ~160dp tall,
`radius/12`), an optional text input "Field name (optional)" below it,
a read-only summary row (area values, same three-value layout as 4.7),
primary button "Save and analyze." On tap: navigates to Home in the
Home Dashboard's loading state (4.5) while the backend/ML request is in
flight.

### 4.9 Field Analysis (Full Detail)

Purpose: expanded view behind "View full analysis," for a farmer who
wants more than the Home summary.

Layout: header "Field analysis," then the field summary card (3.7)
repeated at top, followed by a vertical stack of full-width status
cards (one per row instead of 2-column) each expanded with a
`type/caption` one-line explanation beneath the value — e.g. Crop
health: "Good" / "Your crop shows no signs of stress." Soil moisture:
"Low" / "Moisture has been dropping over the last 3 days." Growth
stage: "Flowering" / "Your crop is in its flowering stage, typically
lasting 2–3 weeks." Irrigation: full advisory block reproducing the
alert banner content plus the recommended litres/acre figure. Below
all cards: a `type/micro` `text/muted` line "Confidence: High · Last
analyzed 2 hours ago." No raw model output (NDVI, SMI, probability
scores) is ever shown, even here — this is the "advanced" screen only
in the sense of more sentences, not more technical data. A collapsed
"Technical details" disclosure at the very bottom (secondary,
low-emphasis text link, not a button) can reveal raw values for internal/
debug builds only — hidden entirely in the production farmer-facing
build.

### 4.10 Market Screen

Layout, top to bottom:
1. Header "Market."
2. Crop selector row (component 3.12) — see open question in Section 9
   on whether this is needed for V1's single-crop reality.
3. Price card (`color/surface`, `radius/12`, padding 14dp): two-column
   row — left "Current price" (`type/caption`) over value
   (`type/card-title`, e.g. "Rs 2,450"), unit below ("per quintal",
   `type/micro`); right "MSP" (`type/caption`) over value
   (`type/card-title`, e.g. "Rs 2,275"), and a `type/micro` line
   "+7.7% above MSP" in `color/success`. Below a divider: "7-day trend"
   label, sparkline (component 3.10), and a `type/micro` trend summary
   ("Rising, up 6.2%") colored by direction.
4. Recommendation card (component 3.5). Example: "Partial sell
   recommended," confidence badge "High confidence," body "Consider
   selling about 40% now and holding the rest," reasoning "Prices are
   above MSP and rising, but some uncertainty remains in the next 2
   weeks."
5. Secondary button "See reasoning in detail" (see open question 9.3).
6. `type/micro` `text/muted` centered: "Updated 2 hours ago."
7. Bottom navigation + FAB.

States: same failure/offline/outdated pattern as Home (Section 4.5),
applied to the price and recommendation cards instead of the field
cards.

### 4.11 History

Purpose: answer "is my field getting better or worse?" — not an
analytics dashboard.

Layout: header "History," then a vertical timeline list — each entry is
a row with a date label (`type/caption`, `text/secondary`) on the left
and a compact 3-line summary on the right (Crop health, Moisture,
Irrigation status — `type/body`), separated by `0.5dp` `color/border`
dividers, no cards per entry (keeps a long list lightweight). No graphs
in V1. Empty state (new field, no history yet): centered icon + `type/
body` "Your field's history will appear here after its first analysis."

### 4.12 Profile

Layout: header "Profile" (or reached via avatar tap, no bottom-nav
slot). Top: large avatar (64dp) + name (`type/title`) + phone number
(`type/caption`, `text/muted`), centered. Below: a plain list of rows
(44dp each, leading icon + label + trailing chevron, `color/border`
divider between): "Language," "Edit field," "Notifications," "Help,"
"Log out" (last row in `color/danger` text, no icon color change on
others). No FAB on this screen.

### 4.13 Voice Assistant Overlay

Purpose: interaction layer over the whole app, not a separate screen —
implemented as a bottom sheet that rises from the FAB tap.

Layout: sheet slides up from bottom, `radius/16` top corners only,
`color/surface` background, drag handle bar centered top (4dp tall,
32dp wide, `color/border`). States within the sheet:
- **Idle/listening:** centered large mic icon (40dp) inside a 72dp
  circle (`bg/accent`), pulsing ring animation (simple opacity pulse,
  not a heavy animation) while actively listening, `type/caption`
  "Listening…" below, small "Tap to stop" hint.
- **Processing:** mic icon replaced with a lightweight indeterminate
  spinner, label "Thinking…"
- **Response:** the farmer's transcribed question shown as a
  right-aligned chat-style bubble (`bg/accent`, `text/primary`), the
  assistant's spoken response shown as a left-aligned bubble
  (`color/surface`, `0.5dp` border), with a small speaker icon button
  to replay audio. A text input row at the very bottom of the sheet
  allows typing a follow-up instead of speaking (accessibility
  fallback).
- **Error:** `type/body` `color/danger` "I couldn't hear that clearly.
  Try again?" with a retry mic button.

The sheet always has access to current field/crop/market context per
Section 18 of the product plan (grounding — LLM never invents
app-specific values).

---

## 5. Navigation Map

```
Splash
  → (new user) Language Selection → Login → OTP → Field Setup (4.6-4.8) → Home
  → (returning user) Home

Home ⇄ Field Analysis Detail
Home ⇄ Market
Home ⇄ History
Home → Profile (via avatar)
Any of Home/Field/Market → Voice Assistant (sheet, not a route)
Profile → Edit field → Field Setup (4.7-4.8) re-entered
```

Bottom nav (Home, Field, Market, History) are peer tabs — switching
between them does not push a new back-stack entry. Field Setup, Field
Analysis Detail, Profile, and Voice Assistant are all reached by
forward navigation and have a back arrow / dismiss gesture.

---

## 6. Shared State Patterns (apply across all data-driven screens)

| State | Visual treatment |
|---|---|
| Loading | Flat skeleton rectangles (no shimmer), one-line status caption |
| Low confidence | Neutral gray "Limited confidence" badge + softened advisory language |
| No coverage | Neutral placeholder values ("—") + explanatory caption, no error color |
| Outdated | `type/micro` `text/muted` "Last analyzed/updated Xh/d ago" |
| API failure | Dismissible `bg/danger` banner at top of screen, last cached data still shown below |
| Offline | Dismissible neutral/gray banner at top of screen, last cached data still shown below |

These are never full-screen takeovers except on first-ever load with no
cached data at all (in which case: centered icon + explanatory
`type/body` text + retry button, no bottom nav content behind it).

---

## 7. Accessibility & Performance Notes

- Minimum touch target: 44x44dp for all interactive elements.
- Text contrast: all text/background pairs above meet WCAG AA at
  minimum given outdoor glare conditions.
- No animation heavier than a simple opacity/scale transition — no
  Lottie-style complex animations in V1, for performance on low-end
  devices.
- All icons paired with text labels except the FAB (mic-only, but has
  an accessibility label "Voice assistant").

---

## 8. Open Questions

1. **Market crop tabs** — keep multi-crop browsing UI (4.10, step 2),
   or remove entirely for V1 since a farmer has one field/one crop?
2. **Voice FAB scope** — persistent on Home/Field/Market only (current
   spec), or also on History/Field Analysis Detail?
3. **"See reasoning in detail"** (4.10, step 5) — does this need its
   own screen, or should it become an inline expand/accordion within
   the recommendation card?

---

## 9. Change Log

- v2: Expanded to full screen-by-screen specification (Splash through
  Voice Assistant), design tokens, component library, navigation map,
  and shared state patterns — written for handoff to a UI-generation
  tool.
- v1: Initial pass covering Home Dashboard, Field Boundary Drawing, and
  Market screen only.
